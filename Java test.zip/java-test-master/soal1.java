class javaTest {
    public static void main(String[] args){
        double num1 = 7.25;
        int num2 = 4;

        System.out.println("The largest number of two number is : " + Math.max(num1, num2));
        System.out.println("The smallest number of two number is : " + Math.min(num1, num2));
    }
}